from django.shortcuts import render
from first_app.models import Topic,Webpage,AccessRecord

# Create your views here.
from django.http import HttpResponse

# def index(request):
#     return HttpResponse("hello world")

# def index(request):
#     my_dict = {'insert_me':"Now I am coming from first_app/index.html!"}
#     return render(request,'first_app/index.html',context=my_dict)

def index(request):
    webpages_list = AccessRecord.objects.order_by('date')
    date_dict = {"access_records":webpages_list}
    return render(request,'first_app/index.html',date_dict)