from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def index(request):
    my_dict={'insert_me':" this is coming from views.index.html <br>",'insert_again':" this is again"}
    # l="insert_me"
    # return HttpResponse("Welcome to First Application")
    return render(request,'first_app/index.html',context=my_dict)