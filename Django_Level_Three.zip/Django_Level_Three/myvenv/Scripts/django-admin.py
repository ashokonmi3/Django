#!c:\my\p\study\django\practice\django_level_three\myvenv\scripts\python3.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
