"""pytester is needed for testing plugins."""
pytest_plugins = 'pytester'
