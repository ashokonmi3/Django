from some_package.some_module import *
